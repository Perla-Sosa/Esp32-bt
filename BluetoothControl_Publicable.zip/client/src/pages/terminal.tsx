import { BluetoothTerminal } from '@/components/bluetooth-terminal';

export default function Terminal() {
  return <BluetoothTerminal />;
}
